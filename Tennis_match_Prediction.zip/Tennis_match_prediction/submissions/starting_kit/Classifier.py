from sklearn.linear_model import LogisticRegression
from sklearn.base import BaseEstimator


class Classifier(BaseEstimator):
    def __init__(self):
        self.reg = LogisticRegression()

    def fit(self, X, y):
        self.reg.fit(X, y)

    def predict(self, X):
        print("hadi")
        return self.reg.predict(X)