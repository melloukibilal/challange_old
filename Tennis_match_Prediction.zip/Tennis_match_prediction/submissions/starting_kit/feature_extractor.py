import os
import pandas as pd
from tqdm import tnrange


class FeatureExtractor(object):
    def __init__(self):
        pass

    def fit(self, X_df, y_array):
        pass

    def transform(self, X):
        Players = set(X.Player1).union(set(X.Player2)) 
        Players = list(Players)
        players_dict ={}
        p = len(Players)
        for i in range(p):
            players_dict[Players[i]]=i
            
        n = len(X)
        X.reset_index(inplace=True)
        X.drop(columns="index",axis=1,inplace=True)
        for i in tnrange(n):
                X.loc[i,"Player1"] = players_dict[X.loc[i,"Player1"]]
                X.loc[i,"Player2"] = players_dict[X.loc[i,"Player2"]]
        X.Surface = pd.factorize(X.Surface)[0]
        X.Tournament = pd.factorize(X.Tournament)[0]
        X.drop(columns = ["Date"],inplace = True)
        X.dropna(inplace=True)
        X.reset_index(inplace=True)
        X.drop(columns="index",axis=1,inplace=True)
        return X