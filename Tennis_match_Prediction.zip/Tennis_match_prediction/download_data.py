from urllib.request import urlopen  
import os.path as osp
import os
import logging
import zipfile
from glob import glob

def download_file(url_str, path):
    url = urlopen(url_str)
    output = open(path, 'wb')
    output.write(url.read())
    output.close()

BASE_URL = 'http://tennis-data.co.uk'
DATA_DIR = "tennis_data"
ATP_DIR = './{}/ATP'.format(DATA_DIR)

ATP_URLS = [BASE_URL + "/%i/%i.zip" % (i,i) for i in range(2000,2019)]
os.makedirs(osp.join(ATP_DIR, 'archives'), exist_ok=True)

for dl_path in ATP_URLS:
    #logging.info("downloading & extracting file %s", dl_path)
    archive_path = osp.join(ATP_DIR, 'archives', osp.basename(dl_path))
    download_file(dl_path, archive_path)
    
ATP_FILES = sorted(glob("%s/*.xls*" % ATP_DIR))

#df_atp = pd.concat([pd.read_excel(f) for f in ATP_FILES], ignore_index=True)
