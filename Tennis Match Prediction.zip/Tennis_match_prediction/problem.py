# -*- coding: utf-8 -*-
"""
Created on Sat Jan 26 16:21:27 2019

@author: Clement_X240
"""
import os
import rampwf as rw
import os.path as osp
import pandas as pd
import numpy as np
from tqdm import tnrange
import zipfile
from glob import glob
from sklearn.utils import shuffle
from rampwf.workflows import FeatureExtractorClassifier
from sklearn.model_selection import ShuffleSplit

problem_title = 'Tennis match prediction'
_target_column_name = 'outcome'
_prediction_label_names = [0,1]

Predictions = rw.prediction_types.make_multiclass(
    label_names=_prediction_label_names)

class Tennis(FeatureExtractorClassifier):

    def __init__(self, workflow_element_names=[
            'feature_extractor', 'classifier']):
        super(Tennis, self).__init__(workflow_element_names)
        self.element_names = workflow_element_names
        
workflow = Tennis()

        
        
score_types = [
    rw.score_types.Accuracy(name='accuracy'),
]




BASE_URL = 'http://tennis-data.co.uk'
DATA_DIR = "tennis_data"
ATP_DIR = './{}/ATP'.format(DATA_DIR)

ATP_URLS = [BASE_URL + "/%i/%i.zip" % (i,i) for i in range(2000,2019)]
os.makedirs(osp.join(ATP_DIR, 'archives'), exist_ok=True)
def get_cv(X, y):
    cv = ShuffleSplit(n_splits=3, test_size=0.10, random_state=42)
    return cv.split(X, y)




def extract_file(archive_path, target_dir):
    zip_file = zipfile.ZipFile(archive_path, 'r')
    zip_file.extractall(target_dir)
    zip_file.close()

    

    
def preprocessing_tool(df_atp):
    df_atp.LRank = df_atp.LRank.replace('NR',0)
    df_atp.WRank = df_atp.WRank.replace('NR',0)
    df_atp.Rank = df_atp.LRank-df_atp.WRank
    df_atp.insert(df_atp.shape[1],"Rank",df_atp.Rank)
    df_atp.drop(columns=["LRank","WRank"],axis=1,inplace=True)
    df_atp.reset_index(inplace=True)
    df_atp.drop(columns=["index"],inplace=True)
    df_atp.Pts = df_atp.LPts-df_atp.WPts
    df_atp.insert(df_atp.shape[1],"Pts",df_atp.Pts)
    df_atp.drop(columns=["LPts","WPts"],axis=1,inplace=True)
    df_atp.B365 = df_atp.B365L-df_atp.B365W
    df_atp.insert(1,"B365",df_atp.B365)
    df_atp.EX = df_atp.EXL-df_atp.EXW
    df_atp.insert(1,"EX",df_atp.EX)
    df_atp.reset_index(inplace=True)
    df_atp.drop(columns=["index"],inplace=True)
    df_atp.drop(columns=["B365W","B365L","EXL","EXW"],axis=1,inplace=True)
    return df_atp
def prepocessing(data):
    data = data.copy()
    not_in  = data[data.Comment!="Completed"].index.values
    data.drop(not_in,axis=0,inplace=True)
    data = data.drop(columns="Comment")
    data.drop(columns=['ATP', 'AvgL', 'AvgW', 'B&WL', 'B&WW','Best of',
                         'CBL', 'CBW', 'GBL', 'GBW', 'IWL', 'IWW','L1', 
                         'L2', 'L3', 'L4', 'L5', 'LBL', 'LBW','W1','W2','W3','W4','W5',
                         'MaxL', 'MaxW', 'PSL', 'PSW', 'SBL', 'SBW', 'SJL',
                         'SJW', 'Series', 'UBL',"Round",'UBW','Wsets','Lsets',"Court","Location"],inplace=True)
    
    data.columns = ['B365L', 'B365W', 'Date', 'EXL', 'EXW', 'LPts', 'LRank', 'Player1',
                      'Surface', 'Tournament', 'WPts', 'WRank', 'Player2']

    data = data[["Date","Player1","Player2","Tournament","Surface",'B365L', 'B365W',
                     'EXL', 'EXW', 'LPts', 'LRank',
                     'WPts', 'WRank']]
    index=-1
    n = len(data)
    data.reset_index(inplace=True)
    data.drop(columns="index",axis=1,inplace=True)
    for i in range(n):
        if(type(data.loc[i,"EXW"])== str):
            index=i
            break
    if (index>=0):
        data.drop([index],inplace=True)
    data.reset_index(inplace=True)
    data.drop(columns="index",axis=1,inplace=True)
    data = preprocessing_tool(data)
    n = data.shape[0]
    outcome = np.zeros(n,dtype='int')
    data.insert(data.shape[1],"outcome",outcome)
    data.reset_index(inplace=True)
    data.drop(columns="index",axis=1,inplace=True)
    
    #data = preprocessing_tool(df_atp)
    data = data[["Date","Player1","Player2","Tournament","Surface",'B365',
                     'EX', 'Pts', 'Rank',"outcome"]]
    n = len(data)
    data = data.sample(n)
    data.reset_index(inplace=True)
    data.drop(columns="index",axis=1,inplace=True)
    n = len(data)
    for i in tnrange(n):
        data.loc[i+n]= [data.loc[i,"Date"],data.loc[i,"Player2"],data.loc[i,"Player1"],
                          data.loc[i,"Tournament"],data.loc[i,"Surface"],-data.loc[i,"B365"],-data.loc[i,"EX"],
                          -data.loc[i,"Pts"],-data.loc[i,"Rank"],1]
    return data    
    

def _read_data(Test=False):
    BASE_URL = 'http://tennis-data.co.uk'
    DATA_DIR = "tennis_data"
    ATP_DIR = './{}/ATP'.format(DATA_DIR)
    
    ATP_URLS = [BASE_URL + "/%i/%i.zip" % (i,i) for i in range(2000,2019)]
    os.makedirs(osp.join(ATP_DIR, 'archives'), exist_ok=True)
    for dl_path in ATP_URLS:
        archive_path = osp.join(ATP_DIR, 'archives', osp.basename(dl_path))
        extract_file(archive_path, ATP_DIR)
    
    ATP_FILES = sorted(glob("%s/*.xls*" % ATP_DIR))

    data = pd.concat([pd.read_excel(f) for f in ATP_FILES], ignore_index=True,sort=True)
    data = prepocessing(data)
    data = shuffle(data)
    data.reset_index(inplace=True)
    data.drop(columns=["index"],inplace=True)
    X,Y = data.drop(columns=["outcome"]),np.array(data["outcome"])
    if(Test):
        return X[::10],Y[::10]
    else:
        return  X,Y

def get_test_data(path="."):
    return _read_data(Test=True)


def get_train_data(path="."):
    return _read_data()